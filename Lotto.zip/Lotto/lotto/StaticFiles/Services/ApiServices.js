﻿//axios基礎設定
 import axios from './Axios.js'

// UserController
export const PostSignin = data => axios.post('/User/SignIn', data).then(respone => { console.log('PostSignin'); return respone; }).catch(error => error);
export const GetListOfUsers = () => axios.get('/User/GetListOfUsers').then(respone => { console.log('GetListOfUsers'); return respone; }).catch(error => error);
export const PostUser = data => axios.post('/User/Add', data).then(respone => { console.log('GetListOfUsers'); return respone; }).catch(error => error);
export const SignOut = () => axios.get('/User/SignOut').then(respone => { console.log('SignOut'); return respone; }).catch(error => error);

//AwardController
export const GetListOfAward = () => axios.get('/Award/GetListOfAward').then(respone => { console.log('GetListOfAward'); return respone; }).catch(error => error);
export const AddAward = data => axios.post('/Award/AddAward', data).then(respone => { console.log('AddAward'); return respone; }).catch(error => error);
export const DeleteAward = data => axios.delete(`/Award/DeleteAward/${data}`).then(respone => { console.log('AddAward'); return respone; }).catch(error => error);
export const GetAwardDetail = data => axios.get('/Award/GetAwardDetail', { params: { aId: data } }).then(respone => { console.log('AddAward'); return respone; }).catch(error => error);
export const UpdateAward = data => axios.post('/Award/UpdateAward', data).then(respone => { console.log('AddAward'); return respone; }).catch(error => error);
export const GetListOfWinner = data => axios.get('/Award/GetListOfWinner', { params: { aId: data } }).then(respone => { console.log('AddAward'); return respone; }).catch(error => error);
export const UpdateWinnerExchanged = data => axios.post('/Award/UpdateWinnerExchanged', data).then(respone => { console.log('AddAward'); return respone; }).catch(error => error);
export const GetListOfAllWinnerDetail = () => axios.get('/Award/GetListOfAllWinnerDetail').then(respone => { console.log('GetListOfAllWinnerDetail'); return respone; }).catch(error => error);

//LotteryController
export const GetWinnersOfLotto = data => axios.post('/Lottery/GetWinnersOfLotto', data).then(respone => { console.log('AddAward'); return respone; }).catch(error => error);
export const ResetAllWinner = () => axios.delete('/Lottery/ResetAllWinner').then(respone => { console.log('AddAward'); return respone; }).catch(error => error);