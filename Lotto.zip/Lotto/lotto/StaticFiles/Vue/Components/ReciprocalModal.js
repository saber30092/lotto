﻿export default {
    data: function () {
        return {
            displayModal: false,
            imgUrl: null,
            count: 4,
            timer: null,
        }
    },
    methods: {
        Show: function () {
            /*this.imgUrl = `../css/img/reciN5.png`,*/
            this.count = 4;
            this.displayModal = true;
            this.timer = setInterval(this.countDown, 1000);
        },
        Close: function () {
            this.displayModal = false;
        },
        countDown: function () {
            /*this.imgUrl = `../css/img/reciN${this.count}.png`;*/
            this.count--;
            if (this.count < 0) {
                clearInterval(this.timer);
                this.Close();
            }
        }
    },
    template:
        `<p-dialog header="" v-model:visible="displayModal" class="p-modal-sm p-modal-md p-modal-lg" v-bind:modal="true">
            <div class="modal-body">
               <img src="../css/img/ReciN1-5.gif" />
            </div>
        </p-dialog>`
}