﻿export default {
    props: ['tempUser'],
    data: function () {
        return {
            displayModal: false,
            userModel: {},
            header: '',
        }
    },
    methods: {
        Show: function (isNew) {
            if (isNew) {
                this.header = '新增會員';
            } else {

            }
            this.displayModal = true;
        },
        Close: function () {
            this.displayModal = false;
        },
        SaveUser: function () {
            this.$emit('save', this.userModel);
        },
        isRequired: function (value) {
            if (!value) {
                return '請務必填寫';
            }
            return true;
        }
    },
    watch: {
        tempUser: {
            handler: function (newVal, oldVal) {
                this.userModel = { ...this.tempUser };
            },
            deep: true,
        }

    },
    template: `
        <p-dialog v-bind:header="header" v-model:visible="displayModal" class="p-modal-sm p-modal-md p-modal-lg" v-bind:position="'top'" v-bind:modal="true">
            <v-form v-on:submit="SaveUser">
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row g-3 mb-5">
                            <div class="d-flex justify-content-center p-0">
                                <h5 class="w-98 fs-4 fw-bold border-bottom border-2 border-gray py-1">員工資訊</h5>
                            </div>
                            <div class="col-md-4">
                                <label for="ItemName" class="form-label">姓名</label>
                                <v-field type="text" class="p-inputtext p-component form-control" id="ItemName" v-model="userModel.UserName"
                                    name="UserName" placeholder="例：西門吹雪" v-bind:rules="isRequired" ></v-field>
                                <error-message name="UserName" style="color:red;"></error-message>
                            </div>
                            <div class="col-md-4">
                                <label for="AwardName" class="form-label">員工編號</label>
                                <v-field type="number" class="p-inputtext p-component form-control" id="StoreData1" v-model="userModel.StaffNumber"
                                    name="StaffNumber" placeholder="例：3345678" v-bind:rules="isRequired" ></v-field>
                                <error-message name="StaffNumber" style="color:red;"></error-message>
                            </div>
                            <div class="col-md-4">
                                <label for="Times" class="form-label">部門</label>
                                <v-field type="text" class="p-inputtext p-component form-control" id="StoreData2" v-model="userModel.Department"
                                    name="Department" placeholder="例：資訊部" v-bind:rules="isRequired" ></v-field>
                                <error-message name="Department" style="color:red;"></error-message>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-dialog-footer">
                    <p-button label="取消" icon="pi pi-times" v-on:click="Close()" class="p-button-text"></p-button>
                    <p-button label="儲存" icon="pi pi-check" autofocus type="submit"></p-button>
                </div>
                </v-form>          
        </p-dialog>`
}