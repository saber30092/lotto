﻿export default {
    props: ['tempAward'],
    data: function () {
        return {
            displayModal: false,
            awardModel: {},
            header: '',
        }
    },
    methods: {
        Show: function (isNew) {
            if (isNew) {
                this.header = '新增獎項';
            } else {
                this.header = '修改獎項';
            }
            this.displayModal = true;
        },
        Close: function () {
            this.displayModal = false;
        },
        SaveAward: function () {
            this.$emit('save', this.awardModel);
        },
        isRequired: function (value) {
            if (!value) {
                return '請務必填寫';
            }
            return true;
        }
    },
    watch: {
        tempAward: {
            handler: function (newVal, oldVal) {
                this.awardModel = { ...this.tempAward };
            },
            deep: true
        }

    },
    template: `
        <p-dialog v-bind:header="header" v-model:visible="displayModal" class="p-modal-sm p-modal-md p-modal-lg" v-bind:position="'top'" v-bind:modal="true">
            <v-form v-on:submit="SaveAward">
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row g-3 mb-5">
                            <div class="d-flex justify-content-center p-0">
                                <h5 class="w-98 fs-4 fw-bold border-bottom border-2 border-gray py-1">獎項資訊</h5>
                            </div>
                            <div class="col-md-4">
                                <label for="ItemName" class="form-label">獎項</label>
                                <v-field type="text" class="p-inputtext p-component form-control" id="ItemName" v-model="awardModel.ItemName"
                                    name="ItemName" placeholder="例：頭獎" v-bind:rules="isRequired" ></v-field>
                                <error-message name="ItemName" style="color:red;"></error-message>
                            </div>
                            <div class="col-md-4">
                                <label for="AwardName" class="form-label">名稱</label>
                                <v-field type="text" class="p-inputtext p-component form-control" id="StoreData1" v-model="awardModel.AwardName"
                                    name="AwardName" placeholder="例：糖果" v-bind:rules="isRequired" ></v-field>
                                <error-message name="AwardName" style="color:red;"></error-message>
                            </div>
                            <div class="col-md-4">
                                <label for="Times" class="form-label">數量</label>
                                <v-field type="number" class="p-inputtext p-component form-control" id="StoreData2" v-model="awardModel.Times"
                                    name="Times" placeholder="例：10" v-bind:rules="isRequired" ></v-field>
                                <error-message name="Times" style="color:red;"></error-message>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="p-dialog-footer">
                    <p-button label="取消" icon="pi pi-times" v-on:click="Close()" class="p-button-text"></p-button>
                    <p-button label="儲存" icon="pi pi-check" autofocus type="submit"></p-button>
                </div>
                </v-form>          
        </p-dialog>`
}