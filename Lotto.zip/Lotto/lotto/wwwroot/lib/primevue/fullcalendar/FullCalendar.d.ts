interface FullCalendarProps {
    events?: any[];
    options?: object;
}

declare class FullCalendar {
    $props: FullCalendarProps;
}

export default FullCalendar;
