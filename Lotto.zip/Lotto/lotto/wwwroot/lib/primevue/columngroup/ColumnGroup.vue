<script>
export default {
    name: 'ColumnGroup',
    props: {
        type: {
            type: String,
            default: null
        }
    },
    render() {
        return null;
    }
}
</script>
