import { ObjectDirective } from 'vue';

declare const Tooltip: ObjectDirective;

export default Tooltip;
