<script>
export default {
    name: 'Row',
    render() {
        return null;
    }
}
</script>
