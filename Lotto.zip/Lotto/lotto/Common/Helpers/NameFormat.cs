﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Common.Helpers
{
    public static class NameFormat
    {
        public static string NameShadow(this string name)
        {
            var nameLen = name.Length;
            if (nameLen == 1)
                return name;
            else if (nameLen == 2)
                return name.Substring(0, 1) + "Ｏ";
            else if (nameLen == 3)
                return name.Substring(0, 1) + "Ｏ" + name.Substring(2, 1);
            else
                return name.Substring(0, 2) + "Ｏ" + name.Substring(3, nameLen - 3);
        }
    }
}
