﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Common.Helpers
{
    public static class DollarFormat
    {
        public static string ChangeAwardName(this string word)
        {
            if (Int32.TryParse(word, out int number))
            {
                return String.Format("{0:C0}", number);
            }
            else
            {
                return word;
            }
        }
    }
}
