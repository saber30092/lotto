﻿using AutoMapper;
using Lotto.Common.Util;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Services.DTO;

namespace Lotto.Common.Profiles
{
    public class AwardProfile : Profile
    {
        public AwardProfile()
        {
            CreateMap<AddAwardViewModel, AwardReq>();
            CreateMap<UpdateAwardViewModel, UpdateAwardReq>();
            CreateMap<UpdateWinnerExchangedViewModel, UpdateWinnerExchangedReq>();
            CreateMap<Winner, WinnerDetailsRsp>()
                .ForMember(n => n.ItemName, o => o.MapFrom(o => o.Award.ItemName))
                .ForMember(n => n.StaffNumber, o => o.MapFrom(o => o.User.StaffNumber))
                .ForMember(n => n.UserName, o => o.MapFrom(o => o.User.UserName))
                .ForMember(n => n.Department, o => o.MapFrom(o => o.User.Department));
        }
    }
}
