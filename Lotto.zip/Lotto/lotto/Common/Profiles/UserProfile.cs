﻿using AutoMapper;
using Lotto.Common.Util;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Services.DTO;

namespace Lotto.Common.Profiles
{
    public class UserProfile:Profile
    {
        public UserProfile()
        {
            CreateMap<User, UserRsp>()
                .ForMember(n => n.UserName, o => o.MapFrom(o => NameShadow.Shadow(o.UserName)));
            CreateMap<User, WinnerRsp>();
            CreateMap<AddUserViewModel, AddUserReq>();
        }

    }
}
