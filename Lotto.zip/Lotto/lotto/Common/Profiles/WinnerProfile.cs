﻿using AutoMapper;
using Lotto.Common.Util;
using Lotto.Repositories.Entities;
using Lotto.Services.DTO;

namespace Lotto.Common.Profiles
{
    public class WinnerProfile : Profile
    {
        public WinnerProfile()
        {
            CreateMap<Winner, WinnerRsp>()
                .ForMember(n => n.StaffNumber, o => o.MapFrom(o => o.User.StaffNumber))
                .ForMember(n => n.UserName, o => o.MapFrom(o => o.User.UserName))
                .ForMember(n => n.Department, o => o.MapFrom(o => o.User.Department));
        }
    }
}
