﻿using Lotto.Controllers.ViewModels;
using System.Threading.Tasks;

namespace Lotto.Services.Interfaces
{
    public interface IUserService
    {
        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> SignIn(SigninViewModel signinViewModel);

        /// <summary>
        /// 查詢所有使用者
        /// </summary>
        /// <returns></returns>
        public Task<ResponseViewModel> GetUsers();

        /// <summary>
        /// 新增使用者
        /// </summary>
        /// <param name="addUserViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> AddUser(AddUserViewModel addUserViewModel);
    }
}
