﻿using Lotto.Controllers.ViewModels;
using Lotto.Services.DTO;
using System.Threading.Tasks;

namespace Lotto.Services.Interfaces
{
    public interface ILotteryService
    {
        /// <summary>
        /// 配合次數的抽獎功能並存入DB
        /// </summary>
        /// <param name="awardReq"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> GetWinnersOfLotto(AwardReq awardReq);

        /// <summary>
        /// 重置得獎者名單(重新抽獎)
        /// </summary>
        /// <returns></returns>
        public Task<ResponseViewModel> ResetAllWinner();
    }
}
