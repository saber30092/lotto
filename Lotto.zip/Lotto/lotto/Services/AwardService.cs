﻿using AutoMapper;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Interfaces;
using Lotto.Services.Interfaces;
using System.Threading.Tasks;
using Lotto.Repositories.Entities;
using Lotto.Common.Enums;
using Lotto.Services.DTO;
using System.Collections.Generic;
using System;
using Lotto.Common.Helpers;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Security.Claims;

namespace Lotto.Services
{
    public class AwardService : IAwardService
    {
        public readonly IMapper _mapper;
        public readonly IAwardRepository _awardRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AwardService(IMapper mapper, IAwardRepository awardRepository, IHttpContextAccessor httpContextAccessor)
        {
            _mapper = mapper;
            _awardRepository = awardRepository;
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="addAwardViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> AddAward(AddAwardViewModel addAwardViewModel)
        {
            var awardReq = _mapper.Map<AwardReq>(addAwardViewModel);
            var response = await _awardRepository.AddAward(awardReq);
            if (response)
                return new ResponseViewModel { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "新增成功" };
            return new ResponseViewModel { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "執行失敗" };
        }

        /// <summary>
        /// 修改獎項
        /// </summary>
        /// <param name="updateAwardViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> UpdateAward(UpdateAwardViewModel updateAwardViewModel)
        {
            var updateAward = _mapper.Map<UpdateAwardReq>(updateAwardViewModel);
            var response = await _awardRepository.UpdateAward(updateAward);
            if (response)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "修改成功" };
            return new ResponseViewModel() { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "修改失敗" };
        }

        /// <summary>
        /// 刪除獎項
        /// </summary>
        /// <param name="aid"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> DeleteAward(string aid)
        {
            var response = await _awardRepository.DeleteAward(aid);
            if (response)
                return new ResponseViewModel { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "刪除成功" };
            return new ResponseViewModel { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "執行失敗" };
        }

        ///<summary>
        ///查詢所有獎項
        ///</summary>
        public async Task<ResponseViewModel> GetListOfAward()
        {
            var response = await _awardRepository.GetListOfAward();
            if (response == null)
            {
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.GetFail, RtnMessage = ReturnCodeEnum.NotFound.ToString() };
            }
            foreach (var item in response)
            {
                item.AwardName = item.AwardName.ChangeAwardName();
            }
            return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnData = response };
        }

        ///<summary>
        ///查詢某獎項的得獎者
        ///</summary>
        public async Task<ResponseViewModel> GetListOfWinner(int aId)
        {
            var allWinner = await _awardRepository.GetListOfWinner(aId);
            if (allWinner == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.GetFail, RtnMessage = ReturnCodeEnum.NotFound.ToString() };

            var winnerRsp = _mapper.Map<IEnumerable<WinnerRsp>>(allWinner);
            string UserRole = _httpContextAccessor.HttpContext.User.Claims.SingleOrDefault(c => c.Type == ClaimTypes.Role).Value;
            if (UserRole == "Staff")
                foreach (var item in winnerRsp) { item.UserName = item.UserName.NameShadow(); }

            return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "查詢成功", RtnData = winnerRsp };
        }

        /// <summary>
        /// 查詢獎品By aId(獎品編號)
        /// </summary>
        /// <param name="aId"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> GetAwardDetailById(int aId)
        {
            var award = await _awardRepository.GetAwardDetailById(aId);
            if (award == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.GetFail, RtnMessage = "查詢錯誤", RtnData = "查無此項獎品" };
            award.AwardName = award.AwardName.ChangeAwardName();
            return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "查詢成功", RtnData = award };
        }

        /// <summary>
        /// 兌換獎項
        /// </summary>
        /// <param name="updateWinnerExchangedViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> UpdateExchaged(UpdateWinnerExchangedViewModel updateWinnerExchangedViewModel)
        {
            var updateExchanged = _mapper.Map<UpdateWinnerExchangedReq>(updateWinnerExchangedViewModel);
            var response = await _awardRepository.UpdateExchaged(updateExchanged);
            if (response)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "修改成功" };
            return new ResponseViewModel() { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "修改失敗" };
        }

        /// <summary>
        /// 查詢中獎人資訊
        /// </summary>
        /// <returns></returns>
        public async Task<ResponseViewModel> GetAllWinnerDetails()
        {
            var details = await _awardRepository.GetAllWinnerDetails();
            if (details == null)
                return null;

            var detailRsp = _mapper.Map<IEnumerable<WinnerDetailsRsp>>(details);
            string UserRole = _httpContextAccessor.HttpContext.User.Claims.SingleOrDefault(c => c.Type == ClaimTypes.Role).Value;
            if (UserRole == "Staff")
                foreach (var item in detailRsp) { item.UserName = item.UserName.NameShadow(); }
            return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "查詢成功", RtnData = detailRsp };
        }
    }
}
