﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Services.DTO
{
    public class UpdateWinnerExchangedReq
    {
        /// <summary>
        /// 員工編號
        /// </summary>
        public string StaffNumber { get; set; }

        /// <summary>
        /// 是否領獎
        /// </summary>
        public string Exchanged { get; set; }
    }
}
