﻿
namespace Lotto.Services.DTO
{
    public class AddWinnerReq
    {
        /// <summary>
        /// 員工編號
        /// </summary>
        public string StaffNumber { get; set; }
        
        /// <summary>
        /// 獎品編號
        /// </summary>
        public int Aid { get; set; }
    }
}
