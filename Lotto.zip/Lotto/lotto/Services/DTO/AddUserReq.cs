﻿
namespace Lotto.Services.DTO
{
    public class AddUserReq
    {
        /// <summary>
        /// 姓名
        /// </summary>
        public string UserName { get; set; }

        /// <summary>
        /// 員工編號
        /// </summary>
        public string StaffNumber { get; set; }

        /// <summary>
        /// 部門
        /// </summary>
        public string Department { get; set; }
    }
}
