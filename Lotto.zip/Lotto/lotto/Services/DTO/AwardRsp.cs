﻿
namespace Lotto.Services.DTO
{
    public class AwardRsp
    {
        /// <summary>
        /// 獎品編號
        /// </summary>
        public int Aid { get; set; }

        /// <summary>
        /// 獎項名稱
        /// </summary>
        public string ItemName { get; set; }

        /// <summary>
        /// 獎品內容
        /// </summary>
        public string AwardName { get; set; }

        /// <summary>
        /// 抽獎次數
        /// </summary>
        public string Times { get; set; }

        /// <summary>
        /// 計算Winner中獎品的次數
        /// </summary>
        public string CountAid { get; set; }

        /// <summary>
        /// 剩餘次數
        /// </summary>
        public string RemainTimes { get; set; }
    }
}
