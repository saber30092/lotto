﻿using AutoMapper;
using Lotto.Common.Enums;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Services
{
    public class LotteryService : ILotteryService
    {
        private readonly IMapper _mapper;
        private readonly ILotteryRepository _lotteryRepository;
        private readonly IAwardRepository _awardRepository;

        public LotteryService(IMapper mapper, ILotteryRepository lotteryRepository, IAwardRepository awardRepository)
        {
            _mapper = mapper;
            _lotteryRepository = lotteryRepository;
            _awardRepository = awardRepository;
        }

        /// <summary>
        /// 配合次數的抽獎功能並存入DB
        /// </summary>
        /// <param name="awardReq"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> GetWinnersOfLotto(AwardReq awardReq)
        {
            //抓傳獎品剩餘次數
            var latestTimes = await _awardRepository.GetAwardDetailById(awardReq.Aid);
            if (Int32.Parse(latestTimes.RemainTimes) == 0)
            {
                var result = await _awardRepository.GetListOfWinner(awardReq.Aid);
                if (result == null)
                    return new ResponseViewModel() { RtnCode = ReturnCodeEnum.GetFail, RtnMessage = ReturnCodeEnum.NotFound.ToString() };

                var response = _mapper.Map<IEnumerable<WinnerRsp>>(result);
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "成功（無剩餘次數）", RtnData = response };
            }

            //抽獎次數
            string drawTimes;
            awardReq.ItemName = awardReq.ItemName.Trim();
            if (awardReq.ItemName == "頭獎" || awardReq.ItemName == "一獎" || awardReq.ItemName == "壹獎" || awardReq.ItemName == "1獎" ) //抓頭獎&壹獎
                drawTimes = "1";
            else
                drawTimes = awardReq.Times;

            //中獎人員名單
            var winners = await _lotteryRepository.GetWinnersOfLotto(drawTimes);
            if (winners == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.GetFail, RtnMessage = ReturnCodeEnum.NotFound.ToString() };

            //中獎人加入Winner
            var staffNoList = winners.Select(p => p.StaffNumber);
            List<AddWinnerReq> list = new List<AddWinnerReq>();
            foreach (var item in staffNoList)
            {
                list.Add(new AddWinnerReq() { Aid = awardReq.Aid, StaffNumber = item });
            }
            var addwinner = await _lotteryRepository.PostWinner(list);
            if(!addwinner)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage ="存入中獎人錯誤" };

            var winnerResult = _mapper.Map<IEnumerable<UserRsp>>(winners);
            return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "成功", RtnData = winnerResult };
        }

        /// <summary>
        /// 重置得獎者名單(重新抽獎)
        /// </summary>
        /// <returns></returns>
        public async Task<ResponseViewModel> ResetAllWinner()
        {
            var response = await _lotteryRepository.ResetAllWinner();
            if (response)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "得獎名單與九宮格摸彩皆已重置" };
            return new ResponseViewModel { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "執行失敗" };
        }
    }
}
