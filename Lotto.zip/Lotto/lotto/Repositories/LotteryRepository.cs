﻿using Dapper;
using Lotto.Common.Enums;
using Lotto.Repositories.Entities;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Lotto.Repositories
{
    public class LotteryRepository : ILotteryRepository
    {
        private readonly IConfiguration _config;

        public LotteryRepository(IConfiguration config)
        {
            _config = config;
        }

        /// <summary>
        /// 配合次數的抽獎功能
        /// </summary>
        /// <param name="times"></param>
        /// <returns></returns>
        public async Task<IEnumerable<User>> GetWinnersOfLotto(string times)
        {
            var role = (int)RoleEnum.Staff;
            var time = Int32.Parse(times);
            string sql = @"SELECT TOP(@Times) U.* FROM [dbo].[User] U
                           LEFT JOIN [dbo].[Winner] W
                           ON U.StaffNumber = W.StaffNumber
                           WHERE Aid IS NULL AND Role = @Role AND Checked = 1
                           ORDER BY NEWID()";
            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                var participant = await connection.QueryAsync<User>(sql, new { Times = time, Role = role });
                if (participant == null)
                    return null;
                return participant;
            }
        }

        /// <summary>
        /// 將抽出中獎者存入DB
        /// </summary>
        /// <param name="addWinners"></param>
        /// <returns></returns>
        public async Task<bool> PostWinner(List<AddWinnerReq> addWinners)
        {
            string sql = @"INSERT INTO [dbo].[Winner] (StaffNumber,Aid)
                         VALUES (@StaffNumber,@Aid)";

            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                bool result = false;
                connection.Open();

                using (var tran = connection.BeginTransaction())
                {
                    try
                    {
                        var response = await connection.ExecuteAsync(sql, addWinners, transaction: tran);
                        if (response > 0) { result = true; }
                        tran.Commit();
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        throw new Exception(ex.Message.ToString());
                    }
                }
                return result;
            }
        }
        
        /// <summary>
        /// 查詢Winner資料表中中獎人資訊
        /// </summary>
        /// <param name="winnerList"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Winner>> GetListOfWinner(IEnumerable<string> winnerList)
        {
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = "SELECT * FROM [dbo].[Winner] WHERE StaffNumber = @StaffNumber";

                var entity = await _connection.QueryAsync<Winner>(sql, winnerList);
                if (entity == null) { return null; }
                return entity;
            }
        }

        /// <summary>
        /// 重置得獎者名單(重新抽獎)
        /// </summary>
        /// <returns></returns>
        public async Task<bool> ResetAllWinner()
        {
            string sql = @"DELETE FROM [dbo].[Winner]";
            using(IDbConnection connection=new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                bool result = false;
                connection.Open();
                try
                {
                    var response = await connection.ExecuteAsync(sql);
                    if (response > 0)
                        result = true;
                }
                catch(Exception ex)
                {
                    throw new Exception(ex.Message.ToString());
                }
                return result;
            }
        }
    }
}
