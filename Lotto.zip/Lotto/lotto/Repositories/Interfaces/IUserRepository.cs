﻿using Lotto.Repositories.Entities;
using Lotto.Services.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Lotto.Repositories.Interfaces
{
    public interface IUserRepository
    {
        /// <summary>
        /// 查詢使用者By員編
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public Task<User> GetUserByStaffNumber(string staffNumber);

        /// <summary>
        /// 查詢使用者名單
        /// </summary>
        /// <returns></returns>
        public Task<IEnumerable<User>> GetUsers();

        /// <summary>
        /// 變更Checked
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public Task<bool> UpdateCheckedByStaffNumber(string staffNumber);

        /// <summary>
        /// 新增User
        /// </summary>
        /// <param name="addUserReq"></param>
        /// <returns></returns>
        public Task<bool> PostUser(AddUserReq addUserReq);
    }
}
