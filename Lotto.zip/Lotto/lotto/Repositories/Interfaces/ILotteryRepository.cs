﻿using Lotto.Repositories.Entities;
using Lotto.Services.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Lotto.Repositories.Interfaces
{
    public interface ILotteryRepository
    {
        /// <summary>
        /// 配合次數的抽獎功能
        /// </summary>
        /// <param name="times"></param>
        /// <returns></returns>
        public Task<IEnumerable<User>> GetWinnersOfLotto(string times);

        /// <summary>
        /// 將抽出中獎者存入DB
        /// </summary>
        /// <param name="addWinners"></param>
        /// <returns></returns>
        public Task<bool> PostWinner(List<AddWinnerReq> addWinners);

        /// <summary>
        /// 查詢Winner資料表中中獎人資訊
        /// </summary>
        /// <param name="list"></param>
        /// <returns></returns>
        public Task<IEnumerable<Winner>> GetListOfWinner(IEnumerable<string> winnerList);

        /// <summary>
        /// 重置得獎者名單(重新抽獎)
        /// </summary>
        /// <returns></returns>
        public Task<bool> ResetAllWinner();
    }
}
