﻿using AutoMapper;
using Dapper;
using Lotto.Repositories.Entities;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Repositories
{
    public class AwardRepository : IAwardRepository
    {
        private readonly IMapper _mapper;
        private readonly IConfiguration _config;

        public AwardRepository(IMapper mapper, IConfiguration config)
        {
            _mapper = mapper;
            _config = config;
        }

        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public async Task<bool> AddAward(AwardReq model)
        {
            string sql = @"INSERT INTO[dbo].[Award](ItemName,AwardName,Times)
                          VALUES(@ItemName,@AwardName,@Times)";
            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                bool result = false;
                connection.Open();
                using (var tran = connection.BeginTransaction())
                {
                    try
                    {
                        var response = await connection.ExecuteAsync(sql, model, transaction: tran);
                        if (response > 0) { result = true; }
                        tran.Commit();
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        throw new Exception(ex.Message.ToString());
                    }
                    return result;
                }
            }
        }

        /// <summary>
        /// 查詢所有獎項
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<AwardRsp>> GetListOfAward()
        {
            string sql = @"SELECT *,(Times - ISNULL(Count_Aid, 0)) AS RemainTimes  FROM Award A LEFT JOIN(SELECT Aid, COUNT(Aid) as Count_Aid FROM WINNER  GROUP BY Aid) W ON A.Aid = W.Aid";
            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                var award = await connection.QueryAsync<AwardRsp>(sql);

                if (award == null)
                {
                    return null;
                }

                return award.ToList();
            }
        }

        /// <summary>
        /// 查詢某獎項的得獎者
        /// </summary>
        /// <param name="aId"></param>
        /// <returns></returns>
        public async Task<IEnumerable<Winner>> GetListOfWinner(int aId)
        {
            string sql = @"SELECT * FROM [dbo].[Winner] W 
                                    LEFT JOIN [dbo].[User] U ON W.StaffNumber = U.StaffNumber
                                    WHERE W.Aid = @Aid
                                    ORDER BY W.StaffNumber";

            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                var winners = await connection.QueryAsync<Winner, User, Winner>(sql, (winner, user) =>
                {
                    winner.User = user;
                    return winner;
                }, new { Aid = aId }, splitOn: "Uid");

                if (winners == null)
                {
                    return null;
                }

                return winners;
            }
        }

        /// <summary>
        /// 刪除獎項
        /// </summary>
        /// <param name="aid"></param>
        /// <returns></returns>
        public async Task<bool> DeleteAward(string aid)
        {
            string sql = @"DELETE FROM [dbo].[Award]
                          WHERE Aid=@aid";
            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                bool result = false;
                connection.Open();

                try
                {
                    var response = await connection.ExecuteAsync(sql, new { aid = aid });
                    if (response == 1)
                        result = true;
                }
                catch (Exception ex)
                {
                    throw new Exception(ex.Message.ToString());
                }
                return result;
            }
        }

        /// <summary>
        /// 修改獎項
        /// </summary>
        /// <param name="updateAwardReq"></param>
        /// <returns></returns>
        public async Task<bool> UpdateAward(UpdateAwardReq updateAwardReq)
        {
            string sql = @"UPDATE [dbo].[Award]
                          SET ItemName=@ItemName,
                              AwardName=@AwardName,
                              Times=@Times
                          WHERE Aid=@aid";
            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                bool result = false;
                connection.Open();
                using (var tran = connection.BeginTransaction())
                {
                    try
                    {
                        var response = await connection.ExecuteAsync(sql, updateAwardReq, transaction: tran);
                        tran.Commit();
                        if (response == 1) { result = true; }
                        return result;
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        throw new Exception(ex.Message.ToString());
                    }
                }
            }
        }

        /// <summary>
        /// 查詢獎品 By aId(獎品編號)
        /// </summary>
        /// <param name="aId"></param>
        /// <returns></returns>
        public async Task<AwardRsp> GetAwardDetailById(int aId)
        {
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"SELECT *,(Times - ISNULL(Count_Aid, 0)) AS RemainTimes  
                                        FROM Award A
                                        LEFT JOIN(SELECT Aid, COUNT(Aid) as Count_Aid FROM WINNER
                                        GROUP BY Aid) W ON A.Aid = W.Aid
                                         WHERE A.Aid = @Aid";
                var entity = await _connection.QuerySingleOrDefaultAsync<AwardRsp>(sql, new { Aid = aId });
                if (entity == null)
                    return null;
                return entity;
            }
        }

        /// <summary>
        /// 兌換獎項
        /// </summary>
        /// <param name="updateWinnerExchangedReq"></param>
        /// <returns></returns>
        public async Task<bool> UpdateExchaged(UpdateWinnerExchangedReq updateWinnerExchangedReq)
        {
            string sql = @"UPDATE [dbo].[Winner] 
                          SET Exchanged=@Exchanged
                          WHERE StaffNumber=@StaffNumber";
            using (IDbConnection connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                bool result = false;
                connection.Open();
                using (var tran = connection.BeginTransaction())
                {
                    try
                    {
                        var response = await connection.ExecuteAsync(sql, updateWinnerExchangedReq, transaction: tran);
                        tran.Commit();
                        if (response == 1) { result = true; }
                        return result;
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        throw new Exception(ex.Message.ToString());
                    }
                }
            }
        }

        /// <summary>
        /// 查詢中獎人資訊
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<Winner>> GetAllWinnerDetails()
        {
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"SELECT * FROM [dbo].[Winner] W 
                                            INNER JOIN [dbo].[Award] A ON W.Aid = A.Aid 
                                            INNER JOIN [dbo].[User] U ON W.StaffNumber = U.StaffNumber
                                            ORDER BY W.Aid";

                var winners = await _connection.QueryAsync<Winner, Award, User, Winner>(sql, (winner, award, user) =>
               {
                   winner.User = user;
                   winner.Award = award;
                   return winner;
               }, splitOn: "Aid, Uid");

                if (winners == null)
                    return null;
                return winners;
            }
        }
    }
}
