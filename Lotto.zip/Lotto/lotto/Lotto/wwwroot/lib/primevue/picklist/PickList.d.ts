import { VNode } from 'vue';

interface PickListProps {
    modelValue?: any[][];
    selection?: any[][];
    dataKey?: string;
    metaKeySelection?: boolean;
    listStyle?: any;
    responsive?: boolean;
    breakpoint?: string;
}

interface PickListItemSlotInterface {
    item: any;
    index: number;
}

declare class PickList {
    $props: PickListProps;
    $emit(eventName: 'update:modelValue', value: any[]): this;
    $emit(eventName: 'update:selection', value: any[]): this;
    $emit(eventName: 'reorder', e: { originalEvent: Event, value: any[]; direction: string, listIndex: number}): this;
    $emit(eventName: 'selection-change', e: { originalEvent: Event, value: any[]}): this;
    $emit(eventName: 'move-to-target', e: { originalEvent: Event, items: [] }): this;
    $emit(eventName: 'move-all-to-target', e: { originalEvent: Event, items: [] }): this;
    $emit(eventName: 'move-to-source', e: { originalEvent: Event, items: [] }): this;
    $emit(eventName: 'move-all-tou-source', e: { originalEvent: Event, items: [] }): this;
    $slots: {
        header: VNode[];
        item: PickListItemSlotInterface;
        sourceheader: VNode[];
        targetheader: VNode[];
        sourcecontrolsstart: VNode[];
        sourcecontrolsend: VNode[];
        movecontrolsstart: VNode[];
        movecontrolsend: VNode[];
        targetcontrolsstart: VNode[];
        targetcontrolsend: VNode[];
    }
}

export default PickList;
