interface RowProps {}

declare class Row {
    $props: RowProps;
}

export default Row;
