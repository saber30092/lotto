interface ScrollTopProps {
    target?: string;
    threshold?: number;
    icon?: string;
    behavior?: string;
}

declare class ScrollTop {
    $props: ScrollTopProps;
}

export default ScrollTop;
