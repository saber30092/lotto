interface ColumnGroupProps {
    type?: string;
}

declare class ColumnGroup {
    $props: ColumnGroupProps;
}

export default ColumnGroup;
