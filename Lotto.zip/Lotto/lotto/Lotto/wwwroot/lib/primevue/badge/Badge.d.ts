interface BadgeProps {
    value?: any;
    severity?: string;
    size?: string;
}

declare class Badge {
    $props: BadgeProps;
}

export default Badge;
