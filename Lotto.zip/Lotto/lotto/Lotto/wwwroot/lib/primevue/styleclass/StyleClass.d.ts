import { ObjectDirective } from 'vue';

declare const StyleClass: ObjectDirective;

export default StyleClass;
