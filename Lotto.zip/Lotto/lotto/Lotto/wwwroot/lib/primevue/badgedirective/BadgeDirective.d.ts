import { ObjectDirective } from 'vue';

declare const BadgeDirective: ObjectDirective;

export default BadgeDirective;
