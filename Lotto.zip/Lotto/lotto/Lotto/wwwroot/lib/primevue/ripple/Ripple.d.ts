import { ObjectDirective } from 'vue';

declare const Ripple: ObjectDirective;

export default Ripple;
