interface AvatarGroupProps {}

declare class AvatarGroup {
    $props: AvatarGroupProps;
}

export default AvatarGroup;
