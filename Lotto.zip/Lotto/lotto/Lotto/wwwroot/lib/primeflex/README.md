# PrimeFlex
PrimeFlex is a lightweight responsive CSS utility library to accompany Prime UI libraries and static webpages as well.

See [PrimeFlex homepage](http://www.primefaces.org/primeflex) for live showcase and documentation.

![alt text](http://www.primefaces.org/images/primeflex.png "PrimeFlex")