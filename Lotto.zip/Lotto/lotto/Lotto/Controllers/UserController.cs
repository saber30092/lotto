﻿using AutoMapper;
using Lotto.Common.Enums;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Lotto.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        private readonly IMapper _mapper;
        private readonly IRegisterService _registerService;
        private readonly IUserService _userService;

        public UserController(IMapper mapper, IRegisterService registerService, IUserService userService)
        {
            _mapper = mapper;
            _registerService = registerService;
            _userService = userService;
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 註冊
        /// </summary>
        /// <param name="registerViewModel"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] RegisterViewModel registerViewModel)
        {
            if (!ModelState.IsValid)
                return BadRequest(new ResponseViewModel() { RtnData = "註冊錯誤", RtnMessage = "填寫資訊不完整" });

            var result = await _registerService.CreateUser(registerViewModel);
            return Ok(result);
        }

        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> SignIn([FromBody] SigninViewModel signinViewModel)
        {
            if (!ModelState.IsValid)
                return BadRequest(new ResponseViewModel() { RtnData = "登入錯誤", RtnMessage = "填寫資訊不完整" });

            var result = await _userService.SignIn(signinViewModel);
            if (result.RtnCode == ReturnCodeEnum.Ok)
            {
                User data = (User)result.RtnData;
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, data.StaffNumber),
                    new Claim(ClaimTypes.Role, data.Role.ToString()),
                    new Claim("Uid", data.Uid.ToString())
                };
                ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                AuthenticationProperties authenticationProperties = new AuthenticationProperties
                {
                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(60),
                    IsPersistent = true
                };
                await HttpContext.SignInAsync(new ClaimsPrincipal(claimsIdentity), authenticationProperties);
            }
            return Ok(result);
        }

        /// <summary>
        /// 登出
        /// </summary>
        /// <returns></returns>        
        public async Task<IActionResult> SignOut()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Ok(new ResponseViewModel() { RtnMessage = "登出成功" });
        }

        /// <summary>
        /// 查詢所有使用者
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> GetListOfUsers()
        {
            var result = await _userService.GetUsers();
            return Ok(result);
        }

        /// <summary>
        /// 刪除使用者
        /// </summary>
        /// <param name="Uid"></param>
        /// <returns></returns>
        [HttpDelete("/[controller]/[action]/{uid}")]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> Delete([FromRoute] string uid)
        {
            var result = await _userService.DeleteUser(uid);
            return Ok(result);
        }

        /// <summary>
        /// 修改使用者
        /// </summary>
        /// <param name="updateViewModel"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> Update([FromBody] UpdateViewModel updateViewModel)
        {
            var result = await _userService.UpdateUser(updateViewModel);
            return Ok(result);
        }
    }
}
