﻿using Lotto.Controllers.ViewModels;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Lotto.Controllers
{
    [Authorize]
    public class AwardController : Controller
    {
        public readonly IAwardService _awardService;

        public AwardController(IAwardService awardService)
        {
            _awardService = awardService;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult AllMember()
        {
            return View();
        }
        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="addAwardViewModl"></param>
        /// <returns></returns>
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> AddAward([FromBody] AddAwardViewModel addAwardViewModl)
        {
            var response = await _awardService.AddAward(addAwardViewModl);
            return Ok(response);
        }

        /// <summary>
        /// 刪除獎項
        /// </summary>
        /// <param name="aid"></param>
        /// <returns></returns>
        [HttpDelete("[controller]/[action]/{aid}")]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> DeleteAward([FromRoute] string aid)
        {
            var response = await _awardService.DeleteAward(aid);
            return Ok(response);
        }
        ///<summary>
        ///查詢所有獎項
        ///</summary>
        [HttpGet]
        public async Task<IActionResult> GetListOfAward()
        {
            var response = await _awardService.GetListOfAward();
            return Ok(response);
        }

        ///<summary>
        ///查詢某獎項的得獎者
        ///</summary>
        [HttpGet]
        public async Task<IActionResult> GetListOfWinner(int aId)
        {
            var response = await _awardService.GetListOfWinner(aId);
            return Ok(response);
        }

        /// <summary>
        /// 查詢獎品資訊By獎品編號 (aId)
        /// </summary>
        /// <param name="aId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetAwardDetail(int aId)
        {
            var response = await _awardService.GetAwardDetailById(aId);
            return Ok(response);
        }

        /// <summary>
        /// 修改商品資訊
        /// </summary>
        /// <param name="updateAwardViewModel"></param>
        /// <returns></returns>
        [Authorize(Roles = "Administrator, Operator")]
        [HttpPost]
        public async Task<IActionResult> UpdateAward([FromBody]UpdateAwardViewModel updateAwardViewModel)
        {
            var response = await _awardService.UpdateAward(updateAwardViewModel);
            return Ok(response);
        }

    }
}
