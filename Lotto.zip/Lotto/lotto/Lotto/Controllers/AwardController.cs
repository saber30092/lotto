﻿using Lotto.Controllers.ViewModels;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Controllers
{
    public class AwardController : Controller
    {
        public readonly IAwardService _awardService;

        public AwardController(IAwardService awardService)
        {
            _awardService = awardService;
        }

        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="addAwardViewModl"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> AddAward([FromBody] AddAwardViewModel addAwardViewModl)
        {
            var response = await _awardService.AddAward(addAwardViewModl);
            return Ok(response);
        }
        
    }
}
