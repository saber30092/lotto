﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Controllers.ViewModels
{
    public class UpdateViewModel
    {
        /// <summary>
        /// 姓名
        /// </summary>
        [Required]
        public string UserName { get; set; }

        /// <summary>
        /// 部門
        /// </summary>
        [Required]
        public string Department { get; set; }
    }
}
