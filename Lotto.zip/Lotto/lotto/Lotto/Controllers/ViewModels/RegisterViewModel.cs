﻿using Lotto.Common.Enums;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Controllers.ViewModels
{
    public class RegisterViewModel
    {
        /// <summary>
        /// 姓名
        /// </summary>
        [Required]
        public string UserName { get; set; }
        /// <summary>
        /// 員工編號
        /// </summary>
        [Required]
        public string StaffNumber { get; set; }
        /// <summary>
        /// 密碼
        /// </summary>
        [Required]
        public string UserKey { get; set; }
        /// <summary>
        /// 部門
        /// </summary>
        [Required]
        public string Department { get; set; }
        /// <summary>
        /// 角色
        /// </summary>
        [Required]
        public string Role { get; set; }
        /// <summary>
        /// 照片
        /// </summary>        
        public string Image { get; set; }
    }
}
