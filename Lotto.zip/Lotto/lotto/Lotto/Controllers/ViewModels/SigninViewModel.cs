﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Controllers.ViewModels
{
    /// <summary>
    /// 登入ViewModel
    /// </summary>
    public class SigninViewModel
    {
        /// <summary>
        /// 帳號
        /// </summary>
        [Required]
        public string StaffNumber { get; set; }

        /// <summary>
        /// 密碼
        /// </summary>
        //[Required]
        //public string UserKey { get; set; }
    }
}
