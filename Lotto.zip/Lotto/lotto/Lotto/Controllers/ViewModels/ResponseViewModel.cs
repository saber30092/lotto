﻿using Lotto.Common.Enums;

namespace Lotto.Controllers.ViewModels
{
    public class ResponseViewModel
    {
        /// <summary>
        /// 回傳狀態碼
        /// </summary>
        public ReturnCodeEnum RtnCode { get; set; } = ReturnCodeEnum.Ok;

        /// <summary>
        /// 回傳狀態訊息
        /// </summary>
        public string RtnMessage { get; set; } = "";

        /// <summary>
        /// 回傳狀態資料
        /// </summary>
        public object RtnData { get; set; } = default(object);
    }
}
