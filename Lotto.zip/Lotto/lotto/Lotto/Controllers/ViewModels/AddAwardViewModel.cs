﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Controllers.ViewModels
{
    public class AddAwardViewModel
    {
        /// <summary>
        /// 獎項名稱
        /// </summary>
        public string AwardName { get; set; }
    }
}
