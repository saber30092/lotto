﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Controllers.ViewModels
{
    /// <summary>
    /// 獎項名稱
    /// </summary>
    public class AddAwardViewModel
    {
        public string AwardName { get; set; }
    }
}
