﻿using AutoMapper;
using Lotto.Controllers.ViewModels;
using Lotto.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Common.Profiles
{
    public class RegisterProfile:Profile
    {
        public RegisterProfile()
        {
            CreateMap<RegisterViewModel, RegisterReq>();
        }
    }
}
