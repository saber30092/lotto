﻿using AutoMapper;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Common.Profiles
{
    public class AwardProfile : Profile
    {
        public AwardProfile()
        {
            CreateMap<AddAwardViewModel,Award >();
            CreateMap<Award, AwardRsp>();
            CreateMap<UpdateAwardViewModel, UpdateAwardReq>();
        }
    }
}
