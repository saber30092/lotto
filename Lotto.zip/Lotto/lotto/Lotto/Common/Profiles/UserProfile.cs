﻿using AutoMapper;
using Lotto.Common.Util;
using Lotto.Repositories.Entities;
using Lotto.Services.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Common.Profiles
{
    public class UserProfile:Profile
    {
        public UserProfile()
        {
            CreateMap<User, UserRsp>()
                .ForMember(n => n.UserName, o => o.MapFrom(o => NameShadow.Shadow(o.UserName)));
        }

    }
}
