﻿using AutoMapper;
using Lotto.Controllers.ViewModels;
using Lotto.Services.DTO;

namespace Lotto.Common.Profiles
{
    public class UpdateProfile : Profile
    {
        public UpdateProfile()
        {
            CreateMap<UpdateViewModel, UpdateReq>();
        }
    }
}
