﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Common.Enums
{
    public enum RoleEnum
    {
        /// <summary>管理者</summary>
        [Description("管理者")]
        Administrator = 1,

        /// <summary>員工</summary>
        [Description("員工")]
        Staff = 2,

        /// <summary>管理者</summary>
        [Description("已登入使用者")]
        Staff_Login = 3,
    }
}
