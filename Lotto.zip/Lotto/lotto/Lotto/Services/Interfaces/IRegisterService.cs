﻿using Lotto.Controllers.ViewModels;
using System.Threading.Tasks;

namespace Lotto.Services.Interfaces
{
    public interface IRegisterService
    {
        /// <summary>
        /// 新增使用者
        /// </summary>
        /// <param name="registerViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> CreateUser(RegisterViewModel registerViewModel);
    }
}
