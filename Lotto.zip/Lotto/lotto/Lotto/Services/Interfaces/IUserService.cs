﻿using Lotto.Controllers.ViewModels;
using System.Threading.Tasks;

namespace Lotto.Services.Interfaces
{
    public interface IUserService
    {
        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> SignIn(SigninViewModel signinViewModel);

        /// <summary>
        /// 查詢所有使用者
        /// </summary>
        /// <returns></returns>
        public Task<ResponseViewModel> GetUsers();

        /// <summary>
        /// 刪除使用者
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> DeleteUser(string uId);
        
        /// <summary>
        /// 修改使用者
        /// </summary>
        /// <param name="updateViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> UpdateUser(UpdateViewModel updateViewModel);
    }
}
