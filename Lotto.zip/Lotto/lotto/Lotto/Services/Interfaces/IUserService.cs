﻿using Lotto.Controllers.ViewModels;
using System.Threading.Tasks;

namespace Lotto.Services.Interfaces
{
    public interface IUserService
    {
        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> SignIn(SigninViewModel signinViewModel);
    }
}
