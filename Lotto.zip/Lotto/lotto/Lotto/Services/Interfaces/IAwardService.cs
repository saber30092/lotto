﻿using Lotto.Controllers.ViewModels;
using System.Threading.Tasks;

namespace Lotto.Services.Interfaces
{
    public interface IAwardService
    {
        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="addAwardViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> AddAward(AddAwardViewModel addAwardViewModel);

        /// <summary>
        /// 查詢所有獎項
        /// </summary>
        /// <returns></returns>
        public Task<ResponseViewModel> GetListOfAward();

        /// <summary>
        /// 查詢某獎項的得獎者
        /// </summary>
        /// <param name="Aid"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> GetListOfWinner(int Aid);

        /// <summary>
        /// 刪除獎項
        /// </summary>
        /// <param name="aid"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> DeleteAward(string aid);

        /// <summary>
        /// 查詢獎品By aId(獎品編號)
        /// </summary>
        /// <param name="aId"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> GetAwardDetailById(int aId);

        /// <summary>
        /// 修改獎項
        /// </summary>
        /// <param name="updateAwardViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> UpdateAward(UpdateAwardViewModel updateAwardViewModel);

    }
}
