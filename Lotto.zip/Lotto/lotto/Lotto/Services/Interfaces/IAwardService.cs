﻿using Lotto.Controllers.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Services.Interfaces
{
    public interface IAwardService
    {
        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="addAwardViewModel"></param>
        /// <returns></returns>
        public Task<ResponseViewModel> AddAward(AddAwardViewModel addAwardViewModel);
    }
}
