﻿namespace Lotto.Services.DTO
{
    public class UpdateReq
    {
        /// <summary>代號</summary>
        public string Uid { get; set; }

        /// <summary>名稱</summary>
        public string UserName { get; set; }

        /// <summary>部門</summary>
        public string Department { get; set; }
    }
}
