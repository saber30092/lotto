﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Services.DTO
{
    public class UpdateAwardReq
    {
        /// <summary>
        /// 獎品編號
        /// </summary>
        public int Aid { get; set; }
        /// <summary>
        /// 獎品名稱
        /// </summary>
        public string AwardName { get; set; }
        /// <summary>
        /// 抽獎次數
        /// </summary>
        public string Times { get; set; }
    }
}
