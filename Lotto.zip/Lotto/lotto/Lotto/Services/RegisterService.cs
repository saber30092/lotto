﻿using AutoMapper;
using Lotto.Common.Enums;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using System.Threading.Tasks;

namespace Lotto.Services
{
    public class RegisterService : IRegisterService
    {
        private readonly IMapper _mapper;
        private readonly IRegisterRepository _registerRepository;
        private readonly IUserRepository _userRepository;

        public RegisterService(IMapper mapper, IRegisterRepository registerRepository, IUserRepository userRepository)
        {
            _mapper = mapper;
            _registerRepository = registerRepository;
            _userRepository = userRepository;
        }
        /// <summary>
        /// 新增使用者
        /// </summary>
        /// <param name="registerViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> CreateUser(RegisterViewModel registerViewModel)
        {
            var registerReq = _mapper.Map<RegisterReq>(registerViewModel);

            var userResult = await _userRepository.GetUserByStaffNumber(registerReq.StaffNumber);
            if (userResult != null)
                return new ResponseViewModel() { RtnCode=ReturnCodeEnum.AuthenticationFail, RtnData = "註冊錯誤", RtnMessage = "員工編號已註冊" };

            var isSuccess = await _registerRepository.CreateUser(registerReq);
            if (!isSuccess)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.ExecutionFail, RtnData = "註冊失敗", RtnMessage = "註冊帳號失敗" };

            var result = await _userRepository.GetUserByStaffNumber(registerReq.StaffNumber);
            return new ResponseViewModel() { RtnData = result };
        }
    }
}
