﻿using AutoMapper;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Interfaces;
using Lotto.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Lotto.Repositories.Entities;
using Lotto.Common.Enums;

namespace Lotto.Services
{
    public class AwardService: IAwardService
    {
        public readonly IMapper _mapper;
        public readonly IAwardRepository _awardRepository;

        public AwardService(IMapper mapper, IAwardRepository awardRepository)
        {
            _mapper = mapper;
            _awardRepository = awardRepository;
        }
        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="addAwardViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> AddAward(AddAwardViewModel addAwardViewModel)
        {
            var award = _mapper.Map<Award>(addAwardViewModel);
            var response = await _awardRepository.AddAward(award);
            if (response)
                return new ResponseViewModel { RtnCode = ReturnCodeEnum.Ok, RtnMessage = "新增成功" };
            return new ResponseViewModel { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "執行失敗" };
        }
    }
}
