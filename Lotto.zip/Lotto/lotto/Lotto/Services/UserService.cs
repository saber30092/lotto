﻿using AutoMapper;
using Lotto.Common.Enums;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Interfaces;
using Lotto.Services.Interfaces;
using System.Threading.Tasks;

namespace Lotto.Services
{
    public class UserService : IUserService
    {
        private readonly IMapper _mapper;
        private readonly IUserRepository _userRepository;

        public UserService(IMapper mapper, IUserRepository userRepository)
        {
            _mapper = mapper;
            _userRepository = userRepository;
        }
        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> SignIn(SigninViewModel signinViewModel)
        {
            var signinResult =await _userRepository.GetUserByStaffNumberAndUserKey(signinViewModel);
            if (signinResult == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.NotFound, RtnMessage = "登入失敗", RtnData = "帳號密碼錯誤" };
            return new ResponseViewModel() { RtnData = signinResult };
        }
    }
}
