﻿using AutoMapper;
using Lotto.Common.Enums;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Services
{
    public class UserService : IUserService
    {
        private readonly IMapper _mapper;
        private readonly IUserRepository _userRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserService(IMapper mapper, IUserRepository userRepository, IHttpContextAccessor httpContextAccessor)
        {
            _mapper = mapper;
            _userRepository = userRepository;
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> SignIn(SigninViewModel signinViewModel)
        {
            var signinResult = await _userRepository.GetUserByStaffNumberAndUserKey(signinViewModel);
            if (signinResult == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.NotFound, RtnMessage = "登入失敗", RtnData = "帳號密碼錯誤" };
            return new ResponseViewModel() { RtnData = signinResult };
        }

        /// <summary>
        /// 查詢所有會員
        /// </summary>
        /// <returns></returns>
        public async Task<ResponseViewModel> GetUsers()
        {
            var usersResult = await _userRepository.GetUsers();
            if (usersResult == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.GetFail, RtnMessage = "查無資料", RtnData = "查無使用者資料" };
            return new ResponseViewModel() { RtnData = usersResult };
        }

        /// <summary>
        /// 刪除使用者
        /// </summary>
        /// <param name="uId"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> DeleteUser(string uId)
        {
            var deleteuserResult = await _userRepository.DeleteUser(uId);
            if (!deleteuserResult)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "刪除錯誤", RtnData = "查無使用者資料" };
            return new ResponseViewModel() { RtnMessage = "刪除成功" };
        }

        /// <summary>
        /// 修改使用者
        /// </summary>
        /// <param name="updateViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> UpdateUser(UpdateViewModel updateViewModel)
        {
            var updateReq = _mapper.Map<UpdateReq>(updateViewModel);
            updateReq.Uid = _httpContextAccessor.HttpContext.User.Claims.SingleOrDefault(c => c.Type == "Uid").Value;

            var updateuserResult = await _userRepository.UpdateUser(updateReq);
            if (!updateuserResult)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "變更錯誤", RtnData = "修改會員資訊錯誤" };
            return new ResponseViewModel() { RtnMessage = "變更成功" };
        }
    }
}
