﻿using AutoMapper;
using Lotto.Common.Enums;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Lotto.Services
{
    public class UserService : IUserService
    {
        private readonly IMapper _mapper;
        private readonly IUserRepository _userRepository;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public UserService(IMapper mapper, IUserRepository userRepository, IHttpContextAccessor httpContextAccessor)
        {
            _mapper = mapper;
            _userRepository = userRepository;
            _httpContextAccessor = httpContextAccessor;
        }

        /// <summary>
        /// 登入
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public async Task<ResponseViewModel> SignIn(SigninViewModel signinViewModel)
        {
            var userResult = await _userRepository.GetUserByStaffNumber(signinViewModel.StaffNumber);
            if (userResult == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.NotFound, RtnMessage = "登入失敗", RtnData = "查無此員工編號" };

            //變更已報到
            bool changeResult = await _userRepository.UpdateCheckedByStaffNumber(userResult.StaffNumber);
            if(!changeResult)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.ExecutionFail, RtnMessage = "登入失敗", RtnData = "報到失敗" };

            var result = await _userRepository.GetUserByStaffNumber(userResult.StaffNumber);
            var userRsp = _mapper.Map<UserRsp>(result);
            return new ResponseViewModel() { RtnData = userRsp };
        }

        /// <summary>
        /// 查詢所有會員
        /// </summary>
        /// <returns></returns>
        public async Task<ResponseViewModel> GetUsers()
        {
            var usersResult = await _userRepository.GetUsers();
            if (usersResult == null)
                return new ResponseViewModel() { RtnCode = ReturnCodeEnum.GetFail, RtnMessage = "查無資料", RtnData = "查無使用者資料" };
            var userlistRsp = _mapper.Map<IEnumerable<UserRsp>>(usersResult);
            return new ResponseViewModel() { RtnData = userlistRsp };
        }
    }
}
