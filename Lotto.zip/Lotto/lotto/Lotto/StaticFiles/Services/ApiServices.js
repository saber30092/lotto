﻿
// UserController
export const PostSignin = data => axios.post('/User/SignIn', data).then(respone => { console.log('PostSignin'); return respone; }).catch(error => error);
export const GetListOfUsers = () => axios.get('/User/GetListOfUsers').then(respone => { console.log('GetListOfUsers'); return respone; }).catch(error => error);
