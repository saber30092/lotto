﻿
// UserController
export const PostSignin = data => axios.post('/User/SignIn', data).then(respone => { console.log('PostSignin'); return respone; }).catch(error => error);