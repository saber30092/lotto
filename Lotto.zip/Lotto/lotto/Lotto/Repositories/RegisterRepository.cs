﻿using Dapper;
using Lotto.Common.Enums;
using Lotto.Common.Util;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Microsoft.Extensions.Configuration;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Lotto.Repositories
{
    public class RegisterRepository : IRegisterRepository
    {
        private readonly IConfiguration _config;

        public RegisterRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// 新增使用者
        /// </summary>
        /// <param name="registerReq"></param>
        /// <returns></returns>
        public async Task<bool> CreateUser(RegisterReq registerReq)
        {
            bool result = false;
            registerReq.UserKey = RNGCrypto.HMACSHA256(registerReq.UserKey, registerReq.StaffNumber);
            registerReq.Role = RoleEnum.Staff; //預設Role
            
            using(IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"INSERT INTO [dbo].[User] (UserName, StaffNumber, UserKey, Department, Role, Image)
                                         VALUES (@UserName, @StaffNumber, @UserKey, @Department, @Role, @Image);";
                _connection.Open();
                using (var tran = _connection.BeginTransaction())
                {
                    try
                    {
                        var affectedRows = await _connection.ExecuteAsync(sql, registerReq,transaction:tran);
                        if (affectedRows == 1) { result = true; }
                        tran.Commit();                        
                    }
                    catch (Exception ex)
                    {
                        tran.Rollback();
                        throw new Exception(ex.Message.ToString());
                    }
                    return result;
                }
            }            
        }
    }
}
