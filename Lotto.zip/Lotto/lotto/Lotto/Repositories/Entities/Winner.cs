﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Repositories.Entities
{
    public class Winner
    {
        /// <summary>
        /// 得獎編號
        /// </summary>
        public int Wid { get; set; }
        /// <summary>
        /// 員工編號
        /// </summary>
        public string StaffNumber { get; set; }
        /// <summary>
        /// 獎品編號
        /// </summary>
        public int Aid { get; set; }
        /// <summary>
        /// 是否領獎
        /// </summary>
        public string Exchanged { get; set; }
        public User User { get; set; }        
    }
}
