﻿using Lotto.Common.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Repositories.Entities
{
    public class User
    {
        /// <summary>
        /// 序號
        /// </summary>
        public int Uid { get; set; }
        /// <summary>
        /// 名稱
        /// </summary>
        public string UserName { get; set; }
        /// <summary>
        /// 員工編號
        /// </summary>
        public string StaffNumber { get; set; }
        /// <summary>
        /// 密碼
        /// </summary>
        public string UserKey { get; set; }
        /// <summary>
        /// 部門
        /// </summary>
        public string Department { get; set; }
        /// <summary>
        /// 角色
        /// </summary>
        public RoleEnum Role { get; set; }
        /// <summary>
        /// 照片
        /// </summary>
        public string Checked { get; set; }
    }
}
