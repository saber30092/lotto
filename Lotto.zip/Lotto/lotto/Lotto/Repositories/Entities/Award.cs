﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Repositories.Entities
{
    public class Award
    {
        public int Aid { get; set; }
        public string AwardName { get; set; }
    }
}
