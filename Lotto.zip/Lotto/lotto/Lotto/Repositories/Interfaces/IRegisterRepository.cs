﻿using Lotto.Repositories.Entities;
using Lotto.Services.DTO;
using System.Threading.Tasks;

namespace Lotto.Repositories.Interfaces
{
    public interface IRegisterRepository
    {
        /// <summary>
        /// 新增使用者
        /// </summary>
        /// <param name="registerReq"></param>
        /// <returns></returns>
        public Task<bool> CreateUser(RegisterReq registerReq);
    }
}
