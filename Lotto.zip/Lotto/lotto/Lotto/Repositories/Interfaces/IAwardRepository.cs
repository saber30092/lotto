﻿using Lotto.Repositories.Entities;
using Lotto.Services.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Lotto.Repositories.Interfaces
{
    public interface IAwardRepository
    {
        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public Task<bool> AddAward(Award model);

        /// <summary>
        /// 刪除獎項
        /// </summary>
        /// <param name="aid"></param>
        /// <returns></returns>
        public Task<bool> DeleteAward(string aid);

        /// <summary>
        /// 查詢所有獎項
        /// </summary>
        /// <returns></returns>
        public Task<IEnumerable<Award>> GetListOfAward();

        /// <summary>
        /// 查詢某獎項的得獎者
        /// </summary>
        /// <param name="Aid"></param>
        /// <returns></returns>
        public Task<IEnumerable<Winner>> GetListOfWinner(int Aid);

        /// <summary>
        /// 查詢獎品by aId(獎品編號)
        /// </summary>
        /// <param name="aId"></param>
        /// <returns></returns>
        public Task<Award> GetAwardDetailById(int aId);

        /// <summary>
        /// 修改獎項
        /// </summary>
        /// <param name="updateAwardReq"></param>
        /// <returns></returns>
        public Task<bool> UpdateAward(UpdateAwardReq updateAwardReq);
    }
}
