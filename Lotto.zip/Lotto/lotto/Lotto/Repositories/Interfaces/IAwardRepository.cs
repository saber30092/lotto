﻿using Lotto.Repositories.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Repositories.Interfaces
{
    public interface IAwardRepository
    {
        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        public Task<bool> AddAward(Award model);
    }
}
