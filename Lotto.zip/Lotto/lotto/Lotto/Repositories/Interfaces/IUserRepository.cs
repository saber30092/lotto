﻿using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using System.Threading.Tasks;

namespace Lotto.Repositories.Interfaces
{
    public interface IUserRepository
    {
        /// <summary>
        /// 查詢使用者By員編
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public Task<User> GetUserByStaffNumber(string staffNumber);
        /// <summary>
        /// 查詢使用者By員編、密碼
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public Task<User> GetUserByStaffNumberAndUserKey(SigninViewModel signinViewModel);
    }
}
