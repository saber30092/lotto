﻿using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Services.DTO;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Lotto.Repositories.Interfaces
{
    public interface IUserRepository
    {
        /// <summary>
        /// 查詢使用者By員編
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public Task<User> GetUserByStaffNumber(string staffNumber);

        /// <summary>
        /// 查詢使用者By員編、密碼
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public Task<User> GetUserByStaffNumberAndUserKey(SigninViewModel signinViewModel);

        /// <summary>
        /// 查詢使用者名單
        /// </summary>
        /// <returns></returns>
        public Task<IEnumerable<User>> GetUsers();
        
        /// <summary>
        /// 刪除使用者
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public Task<bool> DeleteUser(string uId);

        /// <summary>
        /// 修改使用者
        /// </summary>
        /// <param name="updateViewModel"></param>
        /// <returns></returns>
        public Task<bool> UpdateUser(UpdateReq updateReq);
    }
}
