﻿using Dapper;
using Lotto.Common.Enums;
using Lotto.Common.Util;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Repositories.Interfaces;
using Lotto.Services.DTO;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Threading.Tasks;

namespace Lotto.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly IConfiguration _config;

        public UserRepository(IConfiguration config)
        {
            _config = config;
        }

        /// <summary>
        /// 查詢使用者By員編
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public async Task<User> GetUserByStaffNumber(string staffNumber)
        {
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"SELECT * FROM [dbo].[User] WHERE StaffNumber = @StaffNumber";
                var entity = await _connection.QuerySingleOrDefaultAsync<User>(sql, new { StaffNumber = staffNumber });
                if (entity == null)
                    return null;
                return entity;
            }
        }

        /// <summary>
        /// 查詢使用者By員編、密碼
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public async Task<User> GetUserByStaffNumberAndUserKey(SigninViewModel signinViewModel)
        {
            signinViewModel.UserKey = RNGCrypto.HMACSHA256(signinViewModel.UserKey, signinViewModel.StaffNumber);
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"SELECT * FROM [dbo].[User] WHERE StaffNumber = @StaffNumber AND UserKey = @UserKey";
                var entity = await _connection.QuerySingleOrDefaultAsync<User>(sql, new { StaffNumber = signinViewModel.StaffNumber, UserKey = signinViewModel.UserKey });
                if (entity == null)
                    return null;
                return entity;
            }
        }

        /// <summary>
        /// 查詢使用者名單
        /// </summary>
        /// <returns></returns>
        public async Task<IEnumerable<User>> GetUsers()
        {
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                var role = (int)RoleEnum.Staff;
                string sql = @"SELECT * FROM [dbo].[User] WHERE Role IN (@Role) ORDER BY Uid DESC";
                var entity = await _connection.QueryAsync<User>(sql, new { Role = role });
                if (entity == null)
                    return null;
                return entity;
            }
        }

        /// <summary>
        /// 刪除使用者
        /// </summary>
        /// <param name="uId"></param>
        /// <returns></returns>
        public async Task<bool> DeleteUser(string uId)
        {
            bool result = false;
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"DELETE FROM [dbo].[User] WHERE Uid = @Uid";
                var affectedRows = await _connection.ExecuteAsync(sql, new { Uid = uId });
                if (affectedRows == 1)
                    result = true;
                return result;
            }
        }

        /// <summary>
        /// 修改使用者
        /// </summary>
        /// <param name="updateViewModel"></param>
        /// <returns></returns>
        public async Task<bool> UpdateUser(UpdateReq updateReq)
        {
            bool result = false;
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"UPDATE [dbo].[User] SET UserName = @UserName, Department = @Department WHERE Uid = @Uid";
                var affectedRows = await _connection.ExecuteAsync(sql, new { UserName = updateReq.UserName, Department = updateReq.Department , Uid = updateReq.Uid});
                if (affectedRows == 1)
                    result = true;
                return result;
            }
        }
    }
}
