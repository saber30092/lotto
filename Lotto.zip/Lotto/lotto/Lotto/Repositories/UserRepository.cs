﻿using Dapper;
using Lotto.Common.Util;
using Lotto.Controllers.ViewModels;
using Lotto.Repositories.Entities;
using Lotto.Repositories.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Repositories 
{ 
    public class UserRepository : IUserRepository
    {
        private readonly IConfiguration _config;

        public UserRepository(IConfiguration config)
        {
            _config = config;
        }
        /// <summary>
        /// 查詢使用者By員編
        /// </summary>
        /// <param name="staffNumber"></param>
        /// <returns></returns>
        public async Task<User> GetUserByStaffNumber(string staffNumber)
        {
            using(IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"SELECT * FROM [dbo].[User] WHERE StaffNumber = @StaffNumber";                
                var entity = await _connection.QuerySingleOrDefaultAsync<User>(sql, new { StaffNumber = staffNumber });
                if (entity == null)
                    return null;
                return entity;
            }
        }
        /// <summary>
        /// 查詢使用者By員編、密碼
        /// </summary>
        /// <param name="signinViewModel"></param>
        /// <returns></returns>
        public async Task<User> GetUserByStaffNumberAndUserKey(SigninViewModel signinViewModel)
        {
            signinViewModel.UserKey = RNGCrypto.HMACSHA256(signinViewModel.UserKey, signinViewModel.StaffNumber);
            using (IDbConnection _connection = new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                string sql = @"SELECT * FROM [dbo].[User] WHERE StaffNumber = @StaffNumber AND UserKey = @UserKey";
                var entity = await _connection.QuerySingleOrDefaultAsync<User>(sql, new { StaffNumber = signinViewModel.StaffNumber, UserKey = signinViewModel.UserKey });
                if (entity == null)
                    return null;
                return entity;
            }
        }
    }
}
