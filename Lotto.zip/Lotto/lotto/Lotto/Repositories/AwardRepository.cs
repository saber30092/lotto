﻿using Dapper;
using Lotto.Repositories.Entities;
using Lotto.Repositories.Interfaces;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Repositories
{
    public class AwardRepository: IAwardRepository
    {
        private readonly IConfiguration _config;

        public AwardRepository(IConfiguration config)
        {
            _config = config;
        }

        public async Task<bool> AddAward(Award model)
        {
            string sql = @"INSERT INTO[dbo].[Award](AwardName)
                          VALUES(@AwardName)";
            using (IDbConnection connection=new SqlConnection(_config.GetConnectionString("Lottery_Conn")))
            {
                bool result = false;
                connection.Open();
                using(var tran=connection.BeginTransaction())
                {
                    try
                    {
                        var response = await connection.ExecuteAsync(sql, model, transaction: tran);
                        if (response > 0) { result = true; }
                        tran.Commit();
                    }
                    catch(Exception ex)
                    {
                        tran.Rollback();
                        throw new Exception(ex.Message.ToString());
                    }
                    return result;
                }

            }
        }
    }
}
