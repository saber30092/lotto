﻿using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.ViewComponents
{
    public class Header : ViewComponent
    {
        public readonly IAwardService _awardService;
        public Header(IAwardService awardService)
        {
            _awardService = awardService;
        }
        public async Task<IViewComponentResult> InvokeAsync()
        {
            var response = await _awardService.GetListOfAward();
            var answer=(List<AwardRsp>)response.RtnData;
            return View("Header",answer);
        }
    }
}
