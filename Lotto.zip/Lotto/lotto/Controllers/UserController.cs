﻿using Lotto.Common.Enums;
using Lotto.Controllers.ViewModels;
using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Lotto.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        private readonly IUserService _userService;
        private readonly IConfiguration _configuration;
        public UserController(IUserService userService, IConfiguration configuration)
        {
            _userService = userService;
            _configuration = configuration;
        }

        [AllowAnonymous]
        public IActionResult Index()
        {
            return View();
        }


        [AllowAnonymous]
        public IActionResult SignIn()
        {
            return View();
        }

        /// <summary>
        /// 登入（輸入員工編號登入報到）
        /// </summary>
        /// <param name="signinViewModel">員工編號</param>
        /// <returns></returns>
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> SignIn([FromBody] SigninViewModel signinViewModel)
        {
            if (!ModelState.IsValid)
                return BadRequest(new ResponseViewModel() { RtnData = "登入錯誤", RtnMessage = "員工編號為必填" });

            var result = await _userService.SignIn(signinViewModel);
            if (result.RtnCode == ReturnCodeEnum.Ok)
            {
                UserRsp data = (UserRsp)result.RtnData;
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, data.StaffNumber),
                    new Claim(ClaimTypes.Role, data.Role.ToString())
                };
                ClaimsIdentity claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                AuthenticationProperties authenticationProperties = new AuthenticationProperties
                {
                    ExpiresUtc = DateTimeOffset.UtcNow.AddMinutes(60),
                    IsPersistent = true
                };
                await HttpContext.SignInAsync(new ClaimsPrincipal(claimsIdentity), authenticationProperties);
            }
            return Ok(result);
        }

        /// <summary>
        /// 登出
        /// </summary>
        /// <returns></returns>        
        public async Task<IActionResult> SignOut()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return Redirect(_configuration.GetSection("BaseUrl").Value+"/User/Index");
        }

        /// <summary>
        /// 查詢所有使用者
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> GetListOfUsers()
        {
            var result = await _userService.GetUsers();
            return Ok(result);
        }

        /// <summary>
        /// 新增使用者
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> Add([FromBody] AddUserViewModel addUserViewModel)
        {
            var result = await _userService.AddUser(addUserViewModel);
            return Ok(result);
        }
    }
}
