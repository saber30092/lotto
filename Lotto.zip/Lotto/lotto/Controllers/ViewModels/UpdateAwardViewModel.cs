﻿using System.ComponentModel.DataAnnotations;

namespace Lotto.Controllers.ViewModels
{
    public class UpdateAwardViewModel
    {
        /// <summary>
        /// 獎品編號
        /// </summary>
        public int Aid { get; set; }

        /// <summary>
        /// 獎項名稱
        /// </summary>
        [Required]
        public string ItemName { get; set; }

        /// <summary>
        /// 獎品內容
        /// </summary>
        [Required]
        public string AwardName { get; set; }

        /// <summary>
        /// 抽獎次數
        /// </summary>
        [Required]
        public string Times { get; set; }
    }
}
