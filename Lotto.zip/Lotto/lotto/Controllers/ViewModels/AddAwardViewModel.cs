﻿
using System.ComponentModel.DataAnnotations;

namespace Lotto.Controllers.ViewModels
{
    public class AddAwardViewModel
    {
        /// <summary>
        /// 獎項名稱
        /// </summary>
        [Required]
        public string ItemName { get; set; }

        /// <summary>
        /// 獎品內容
        /// </summary>
        [Required]
        public string AwardName { get; set; }

        /// <summary>
        /// 抽獎次數
        /// </summary>
        [RegularExpression(@"^[0-9]*$", ErrorMessage = "只能輸入數字")]
        [Required]
        public string? Times { get; set; }
    }
}
