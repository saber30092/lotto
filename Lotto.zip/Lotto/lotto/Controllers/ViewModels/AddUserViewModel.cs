﻿using System.ComponentModel.DataAnnotations;

namespace Lotto.Controllers.ViewModels
{
    public class AddUserViewModel
    {
        /// <summary>
        /// 姓名
        /// </summary>
        [Required]
        public string UserName { get; set; }

        /// <summary>
        /// 員工編號
        /// </summary>
        [Required]
        public string StaffNumber { get; set; }

        /// <summary>
        /// 部門
        /// </summary>
        [Required]
        public string Department { get; set; }
    }
}
