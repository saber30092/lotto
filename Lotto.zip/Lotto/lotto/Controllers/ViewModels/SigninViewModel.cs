﻿using System.ComponentModel.DataAnnotations;

namespace Lotto.Controllers.ViewModels
{
    /// <summary>
    /// 登入ViewModel
    /// </summary>
    public class SigninViewModel
    {
        /// <summary>
        /// 帳號
        /// </summary>
        [Required]
        public string StaffNumber { get; set; }
    }
}
