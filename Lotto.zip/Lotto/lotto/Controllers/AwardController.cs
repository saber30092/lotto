﻿using Lotto.Controllers.ViewModels;
using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Lotto.Controllers
{
    [Authorize]
    public class AwardController : Controller
    {
        public readonly IAwardService _awardService;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IConfiguration _configuration;

        public AwardController(IAwardService awardService, IHttpContextAccessor httpContextAccessor, IConfiguration configuration)
        {
            _awardService = awardService;
            _httpContextAccessor = httpContextAccessor;
            _configuration = configuration;
        }

        public IActionResult Index()
        {
            string UserRole = _httpContextAccessor.HttpContext.User.Claims.SingleOrDefault(c => c.Type == ClaimTypes.Role).Value;
            if (UserRole != "Operator")
                return View();
            else
                return Redirect(_configuration.GetSection("BaseUrl").Value + "/Lottery/Index");
        }

        //暫時Route
        public IActionResult AllMember()
        {
            return View();
        }
        public IActionResult AllAward()
        {
            return View();
        }
        [HttpGet]
        public IActionResult AwardSelect(int Aid, string itemName)
        {
            AwardRsp awardRsp = new AwardRsp();
            if (Aid == 0 && itemName == "null")
            {
                awardRsp.Aid = 0;
                awardRsp.ItemName = "所有獎項";
            }
            else
            {
                awardRsp.Aid = Aid;
                awardRsp.ItemName = itemName;
            }
            return View(awardRsp);
        }
        //暫時Route

        /// <summary>
        /// 新增獎項
        /// </summary>
        /// <param name="addAwardViewModl"></param>
        /// <returns></returns>
        [HttpPost]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> AddAward([FromBody] AddAwardViewModel addAwardViewModl)
        {
            var response = await _awardService.AddAward(addAwardViewModl);
            return Ok(response);
        }

        /// <summary>
        /// 刪除獎項
        /// </summary>
        /// <param name="aid"></param>
        /// <returns></returns>
        [HttpDelete("[controller]/[action]/{aid}")]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> DeleteAward([FromRoute] string aid)
        {
            var response = await _awardService.DeleteAward(aid);
            return Ok(response);
        }

        /// <summary>
        /// 查詢所有獎項
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetListOfAward()
        {
            var response = await _awardService.GetListOfAward();
            return Ok(response);
        }

        ///<summary>
        ///查詢某獎項的得獎者
        ///</summary>
        [HttpGet]
        public async Task<IActionResult> GetListOfWinner(int aId)
        {
            var response = await _awardService.GetListOfWinner(aId);
            return Ok(response);
        }

        /// <summary>
        /// 查詢獎品資訊By獎品編號 (aId)
        /// </summary>
        /// <param name="aId"></param>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetAwardDetail(int aId)
        {
            var response = await _awardService.GetAwardDetailById(aId);
            return Ok(response);
        }

        /// <summary>
        /// 修改獎品資訊
        /// </summary>
        /// <param name="updateAwardViewModel"></param>
        /// <returns></returns>
        [Authorize(Roles = "Administrator, Operator")]
        [HttpPost]
        public async Task<IActionResult> UpdateAward([FromBody] UpdateAwardViewModel updateAwardViewModel)
        {
            var response = await _awardService.UpdateAward(updateAwardViewModel);
            return Ok(response);
        }

        /// <summary>
        /// 兌換獎項
        /// </summary>
        /// <param name="updateWinnerExchangedViewModel"></param>
        /// <returns></returns>
        [Authorize(Roles = "Administrator, Operator")]
        [HttpPost]
        public async Task<IActionResult> UpdateWinnerExchanged([FromBody] UpdateWinnerExchangedViewModel updateWinnerExchangedViewModel)
        {
            var reponse = await _awardService.UpdateExchaged(updateWinnerExchangedViewModel);
            return Ok(reponse);
        }

        /// <summary>
        /// 查詢中獎人資訊
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IActionResult> GetListOfAllWinnerDetail()
        {
            var result = await _awardService.GetAllWinnerDetails();
            return Ok(result);
        }
    }
}
