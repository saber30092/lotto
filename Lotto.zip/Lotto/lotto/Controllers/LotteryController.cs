﻿using Lotto.Controllers.ViewModels;
using Lotto.Services.DTO;
using Lotto.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lotto.Controllers
{
    [Authorize]
    public class LotteryController : Controller
    {
        private readonly ILotteryService _lotteryService;
        public LotteryController(ILotteryService lotteryService)
        {
            _lotteryService = lotteryService;
        }
        [Authorize(Roles = "Operator")]
        public IActionResult Index()
        {
            return View();
        }

        /// <summary>
        /// 配合次數的抽獎功能並存入DB
        /// </summary>
        /// <param name="awardReq"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<IActionResult> GetWinnersOfLotto([FromBody] AwardReq awardReq)
        {
            var response = await _lotteryService.GetWinnersOfLotto(awardReq);
            return Ok(response);
        }

        public IActionResult MagicSquare()
        {
            return View();
        }

        /// <summary>
        /// 重置得獎者名單(重新抽獎)
        /// </summary>
        /// <returns></returns> 
        [HttpDelete]
        [Authorize(Roles = "Administrator, Operator")]
        public async Task<IActionResult> ResetAllWinner()
        {
            var response = await _lotteryService.ResetAllWinner();
            return Ok(response);
        }
    }
}
