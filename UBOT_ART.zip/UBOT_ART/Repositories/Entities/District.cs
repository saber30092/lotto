﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace UBOT_ART.Repositories.Entities
{
    public class District
    {
        public int City_ID { get; set; }

        public int District_ID { get; set; }

        public string District_Name { get; set; }
    }
}
