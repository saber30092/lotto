## ViewData
| Key  | Value  | 用途  |
| ------------ | ------------ | ------------ |
|  Title | 頁簽名稱  |   |

## Mitt
| Key  | Value  | 用途  |
| ------------ | ------------ | ------------ |
|  ServerErrorMessages | ModelState  | 傳遞後端驗證錯誤訊息  |
|  GlobalMessage | { title=標題, status=狀態碼, message=訊息 }  | 推播元件  |